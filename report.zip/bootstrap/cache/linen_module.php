<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Linen\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Linen\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);