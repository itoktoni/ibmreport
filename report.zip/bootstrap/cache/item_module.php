<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Item\\Providers\\ModuleServiceProvider',
    1 => 'Modules\\Item\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Item\\Providers\\ModuleServiceProvider',
    1 => 'Modules\\Item\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);