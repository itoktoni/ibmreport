<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Transaction\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Transaction\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);