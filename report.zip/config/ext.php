<?php
return [

    'blade' => 'php_laravel_blade',
    'php' => 'php',
    'json' => 'json',
    'html' => 'html',
    'css' => 'css',
    'env' => 'gear',
    'xml' => 'code',
    'js' => 'javascript',
    'txt' => 'txt',
];
