<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Report\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Report\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);