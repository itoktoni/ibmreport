<?php

return [

    'system' => 'Application',
    'reboot' => 'reboot',
];
