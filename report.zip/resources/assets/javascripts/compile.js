try {
    window.$ = window.jQuery = require('jquery');
    require('bootstrap');
    require('chosen-js');
    require('pace-js');
} catch (e) {

}