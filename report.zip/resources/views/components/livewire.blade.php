@push('javascript')
@livewireAssets(['base_url' => config('app.url')])
@endpush

